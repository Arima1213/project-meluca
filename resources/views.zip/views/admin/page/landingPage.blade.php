@extends('admin.template.templates')

@section('container')
	@include('admin.template.landingNavbar')
@endsection
