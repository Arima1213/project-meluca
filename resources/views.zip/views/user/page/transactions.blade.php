@extends('user.template.templates')

@section('container')
	@include('user.template.landingNavbar')
@endsection
